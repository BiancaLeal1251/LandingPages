function maskPhone(value) {
    // Get the current value of the phone input field
    let phone = $("#tel").val();

    // Remove all non-digit characters from the phone number
    let phoneFormatted = phone.replace(/\D/g, '');

    // Update the phone input field with the formatted value (digits only)
    $("#tel").val(phoneFormatted);

    // Store the formatted phone number in the hidden input field
    $("#phoneValue").val(phoneFormatted);

    // If the formatted phone number has 10 digits
    if (phoneFormatted.length == 10) {
        // Mask the middle four digits of the phone number and update the input field
        $("#tel").val(phoneFormatted.replace(phoneFormatted.substring(3, 7), "****"));
    }
}
