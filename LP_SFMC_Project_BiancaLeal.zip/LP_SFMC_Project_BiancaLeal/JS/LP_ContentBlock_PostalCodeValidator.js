function autocompleteAddress() {
    // Hide any previous postal code error messages
    $(".postalcodeError").css("display", "none");

    // Get the postal code input element
    var el = $("#postalcode");

    // Check if the postal code has exactly 6 characters
    if (el[0].value.length == 6) {
        // Make an AJAX request to the Ziptastic API for address information
        $.ajax({
            url: "https://zip.getziptastic.com/v2/ca/" + el[0].value, // Construct the API URL with the postal code
            cache: false, // Disable caching for this request
            dataType: "json", // Expect JSON data in response
            type: "GET", // HTTP method type
            success: function(result, success) {
                // Hide any postal code error messages upon successful API response
                $(".postalcodeError").css("display", "none");

                // Autofill the city and state input fields with the API response data
                $("#city").val(result.city);
                $("#state").val(result.state);

                // Remove focus from the postal code input field
                $("#postalcode").blur();
            },
            error: function(result, success) {
                // Display an error message if the API request fails
                $(".postalcodeError").css("display", "block");

                // Clear the city and state input fields
                $("#city").val("");
                $("#state").val("");
            }
        });
    } else if (el[0].value.length < 6) {
        // If the postal code has fewer than 6 characters, display an error message
        $(".postalcodeError").css("display", "block");

        // Clear the city and state input fields
        $("#city").val("");
        $("#state").val("");
    }
}
