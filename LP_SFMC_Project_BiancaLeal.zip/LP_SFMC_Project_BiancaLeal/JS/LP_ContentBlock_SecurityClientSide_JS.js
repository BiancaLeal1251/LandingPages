function maskSSN(value) {
    // Remove all non-digit characters from the input value
    let ssnFormatted = value.replace(/\D/g, '');

    // Store the formatted SSN (digits only) in the hidden input field
    $("#ssnValue").val(ssnFormatted);

    // Update the SSN input field with the formatted value (digits only)
    $("#ssn").val(ssnFormatted);

    // If the formatted SSN has 9 digits
    if (ssnFormatted.length == 9) {
        // Mask the middle three digits of the SSN and update the input field
        $("#ssn").val(ssnFormatted.replace(ssnFormatted.substring(2, 5), "***"));
    }
}
